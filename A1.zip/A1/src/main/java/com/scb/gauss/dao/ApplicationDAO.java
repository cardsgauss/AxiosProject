package com.scb.gauss.dao;

import java.util.List;

import com.scb.gauss.bean.Application;
//import com.scb.gauss.bean.Customer;






public interface ApplicationDAO {
	public int add(Application a);
	public List<Application> list();
	public void delete(int id);		
}