package com.scb.gauss.service;

import java.util.List;

import com.scb.gauss.bean.Application;




public interface ApplicationService {
	public int add(Application a);
	public List<Application> list();
	public void delete(int id);
	}
