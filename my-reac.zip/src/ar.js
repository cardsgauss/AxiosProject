import React from 'react';
//import './App.css';
import sc from'./sc.jpg';
import Table from './Table';
import {Link} from 'react-router-dom'
class Ar extends React.Component {
    render() {
        return (

            <div>
                <nav className="navbar navbar-inverse navbar-fixed-top">
                    <div className="container-fluid">
                        <ul className="nav navbar-nav">
                            <li> <img src={sc}  style={{
                                width: 120,
                                height: 45,
                                marginTop: 3
                            }} /> 
                           </li>
                            <li className="active"><a href="http://localhost:3000/">Home</a></li>
                        </ul>
                        <ul className="nav navbar-nav navbar-right">
                            <li style={{
                                size: 45, marginTop: 14,color:'white'
                            }}>Hello user</li>
                            <li><a href="#"><span className="glyphicon glyphicon-user user" aria-hidden="true" ></span></a></li>

                            <li><a href="#"><button className="btn btn-danger btn-xs"><span className="glyphicon glyphicon-log-in"></span>logout</button></a></li>
                        </ul>
                    </div>
                </nav>
            </div>


        );
    }
};
export default Ar;