import React from 'react';
import logo from './logo.svg';
import './App.css';
import CustomerForm from './CustomerForm';
import List from './list';
import {BrowserRouter as Router,Switch,Link,Route} from "react-router-dom";
import PostCustomer from './PostCustomer';
import Table from './Table';
/*function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}*/



class Front extends React.Component {
  constructor(props){
    super(props);
    this.state={show:true};
    this.toggleDiv=this.toggleDiv.bind(this)
  }
  toggleDiv=()=>{
    const{show}=this.state;
    this.setState({show:!show})
  }
  render(){
  return (
    <Router>
      <div>
     
      <Switch>
        <Route  exact path="/list" exact component={List}/>
        <Route path="/form" exact component={PostCustomer}/>
      </Switch>
      </div>
    </Router>
  )
  }
}

export default Front;
