import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";
import {Link} from 'react-router-dom'
//import PostCustomer from './PostCustomer';
class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }

  }
//   constructor(props){
//     super(props);
//     this.state={show:true};
//     this.toggleDiv=this.toggleDiv.bind(this)
//   }
//   toggleDiv=()=>{
//     const{show}=this.state;
//     this.setState({show:!show})
//   }
  componentDidMount() {
    const url = "http://localhost:9122/customer/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }
  render() {
    const columns = [
      {
        Header: "User Id",
        accessor: "id"
      },
      {
        Header: "Email",
        accessor: "email"
      },
      {
        Header: "Name",
        accessor: "name"
      },
      {
        Header: "Email",
        accessor: "email"
      }
      ,
      {
        Header: "Email",
        accessor: "email"
      }
      ,
      {
        Header: "Email",
        accessor: "email"
      }
      ,
      {
        Header: "Email",
        accessor: "email"
      }
      ,
      {
        Header: "Email",
        accessor: "email"
      }
    ]
    return (
        <div>
             <ul>
        
        <li>
          <Link to="/list" >EDIT</Link>
        </li>
        <li>
          <Link to="/form" >CREATE</Link>
          
        </li>
      </ul>
      <ReactTable
      
        columns={columns}
        
        data={this.state.posts}
      >
      </ReactTable>
      </div>
    );
  }
}

export default Table;
